﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using System.Drawing;

namespace SearchEngine
{
    public partial class Form1 : Form
    {
        private readonly HttpClient _httpClient;

        public Form1()
        {
            InitializeComponent();
            _httpClient = new HttpClient();

            resultsPanel.AutoScroll = true;
            resultsPanel.FlowDirection = FlowDirection.TopDown;
            resultsPanel.WrapContents = false;
        }

        private async void searchbutton_Click(object sender, EventArgs e)
        {
            string query = searchbox.Text.Trim();

            if (string.IsNullOrEmpty(query))
            {
                MessageBox.Show("Please enter a search query.");
                return;
            }

            string filterOption = "anytime";
            if (radioFilterWeek.Checked) filterOption = "week";
            else if (radioFilterMonth.Checked) filterOption = "month";
            else if (radioFilterYear.Checked) filterOption = "year";
            else if (radioFilterAnytime.Checked) filterOption = "anytime";

            try
            {
                string url = $"http://localhost:8080/search?query={Uri.EscapeDataString(query)}&filter={filterOption}";
                HttpResponseMessage response = await _httpClient.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    DisplayResults(jsonResponse);
                }
                else
                {
                    MessageBox.Show($"Error: {response.ReasonPhrase}");
                }

                // Update search history
                UpdateSearchHistory(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void DisplayResults(string jsonResponse)
        {
            resultsPanel.Controls.Clear();

            try
            {
                JArray results = JArray.Parse(jsonResponse);

                foreach (var result in results)
                {
                    string title = result["title"]?.ToString() ?? "No title";
                    string link = result["link"]?.ToString() ?? "No link";
                    string snippet = result["snippet"]?.ToString() ?? "No snippet";
                    string publishDate = result["publishDate"]?.ToString() ?? "Not Available";

                    Panel resultPanel = new Panel
                    {
                        BackColor = Color.White,
                        Padding = new Padding(10),
                        Margin = new Padding(10),
                        BorderStyle = BorderStyle.FixedSingle,
                        Width = resultsPanel.ClientSize.Width - 40,
                        Height = 160,
                        AutoSize = false
                    };

                    FlowLayoutPanel layout = new FlowLayoutPanel
                    {
                        FlowDirection = FlowDirection.TopDown,
                        Dock = DockStyle.Fill,
                        Padding = new Padding(5),
                        AutoSizeMode = AutoSizeMode.GrowAndShrink,
                        WrapContents = false
                    };

                    Label titleLabel = new Label
                    {
                        Text = title,
                        Font = new Font("Arial", 12, FontStyle.Bold),
                        AutoSize = true,
                        ForeColor = Color.DarkBlue,
                        Cursor = Cursors.Hand
                    };
                    titleLabel.Click += (s, e) => OpenLink(link);

                    Label snippetLabel = new Label
                    {
                        Text = snippet,
                        Font = new Font("Arial", 9, FontStyle.Regular),
                        AutoSize = true,
                        ForeColor = Color.Black
                    };

                    Label publishDateLabel = new Label
                    {
                        Text = $"Published: {publishDate}",
                        Font = new Font("Arial", 8, FontStyle.Italic),
                        ForeColor = Color.Gray,
                        AutoSize = true
                    };

                    LinkLabel linkLabel = new LinkLabel
                    {
                        Text = "Visit Link",
                        AutoSize = true,
                        LinkColor = Color.Green,
                        Font = new Font("Arial", 9, FontStyle.Underline),
                        Cursor = Cursors.Hand
                    };
                    linkLabel.Click += (s, e) => OpenLink(link);

                    layout.Controls.Add(titleLabel);
                    layout.Controls.Add(snippetLabel);
                    layout.Controls.Add(publishDateLabel);
                    layout.Controls.Add(linkLabel);

                    resultPanel.Controls.Add(layout);
                    resultsPanel.Controls.Add(resultPanel);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error parsing results: {ex.Message}");
            }
        }

        private void OpenLink(string url)
        {
            try
            {
                System.Diagnostics.Process.Start(url);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to open link: {ex.Message}");
            }
        }

        private void UpdateSearchHistory(string query)
        {
            if (!listBoxSearchHistory.Items.Contains(query))
            {
                listBoxSearchHistory.Items.Insert(0, query); // Add to the top of the ListBox
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
